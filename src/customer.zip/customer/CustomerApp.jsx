import { Routes, Route } from 'react-router-dom'
import Footer from './component/footer/Footer'
import HomePage from './pages/HomePage'
import GlobalToast from './component/Toast/GlobalToast'
import Navigation from './component/navigation/Navigation'
import SearchPage from './component/navigation/SearchPage'
import Register from './component/author/Register'
import Login from './component/author/Login'
import ForgotPassword from './component/author/ForgotPassword'
import Profile from './component/author/Profile'
import ContactPage from './component/contactPage/ContactPage'
import TourDetailWrapper from "./component/tourDetail/TourDetailWrapper";
import CarDetailWrapper from './component/carDetail/CarDetailWrapper'

import Tours from './component/tour/Tours'
import CarList from './component/car/CarList'

export default function CustomerApp() {
  return (
    <div className="min-h-screen w-full">
      <Routes>

        {/* ----------- LAYOUT CÓ NAVIGATION + FOOTER ----------- */}
        <Route
          path="/"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <HomePage />
              <Footer />
            </div>
          }
        />

        {/* ========== CÁC TRANG DÙNG LAYOUT CHUNG ========== */}
        <Route
          path="/profile"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <Profile />
              <Footer />
            </div>
          }
        />
        <Route
          path="/contact"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <ContactPage />
              <Footer />
            </div>
          }
        />
        <Route
          path="/tours/:id"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <TourDetailWrapper />
              <Footer />
            </div>
          }
        />
        <Route
          path="/car/:id"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <CarDetailWrapper />
              <Footer />
            </div>
          }
        />
        <Route
          path="/tours"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <Tours />
              <Footer />
            </div>
          }
        />
        <Route
          path="/cars"
          element={
            <div className="flex flex-col min-h-screen">
              <Navigation />
              <CarList />
              <Footer />
            </div>
          }
        />


        {/* ----------- TRANG KHÔNG DÙNG LAYOUT (CHỈ SEARCH) ----------- */}
        <Route path="/search" element={<SearchPage />} />
        <Route path='/register' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/forgot-password' element={<ForgotPassword />} />



        {/* ----------- 404 PAGE ----------- */}
        <Route
          path="*"
          element={
            <div className="p-10 text-center text-gray-600">
              <h2 className="text-2xl font-semibold mb-3">404 - Không tìm thấy trang</h2>
              <a href="/" className="text-green-600 hover:underline font-medium">
                ⬅ Quay lại Trang chủ
              </a>
            </div>
          }
        />

      </Routes>

      <GlobalToast />
    </div>
  );
}
