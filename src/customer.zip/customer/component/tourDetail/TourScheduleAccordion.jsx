import { useState } from "react";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/24/solid";
import { mockTransportationTypes } from "../data/mockData";

export default function TourScheduleAccordion({ schedules, items }) {
    const [openDay, setOpenDay] = useState(null);

    const getTransportName = (id) => {
        const t = mockTransportationTypes.find((x) => x.TransportationID === id);
        return t ? t.TypeName : "N/A";
    };

    const getTransportDesc = (id) => {
        const t = mockTransportationTypes.find((x) => x.TransportationID === id);
        return t ? t.Description : "";
    };

    return (
        <section className="mt-14">
            <h2 className="text-3xl font-bold text-center mb-8">
                Tour Schedule
            </h2>

            <div className="space-y-4">
                {schedules.map((day) => {
                    const isOpen = openDay === day.ScheduleID;

                    return (
                        <div
                            key={day.ScheduleID}
                            className={`rounded-xl border shadow-sm transition 
                                overflow-hidden ${isOpen ? "bg-blue-50" : "bg-white"}`}
                        >
                            {/* ========== HEADER ========== */}
                            <button
                                className="w-full flex justify-between items-center px-6 py-4 text-left"
                                onClick={() => setOpenDay(isOpen ? null : day.ScheduleID)}
                            >
                                <div>
                                    <h3 className="text-lg font-semibold">
                                        Day {day.DayNumber}: {day.Title}
                                    </h3>

                                    <p className="mt-1 text-sm text-gray-600 flex items-center gap-2">
                                        <img
                                            src="https://cdn-icons-png.flaticon.com/512/1046/1046784.png"
                                            className="w-5 opacity-70"
                                        />
                                        {day.MealInfo}
                                    </p>
                                </div>

                                {isOpen ? (
                                    <ChevronUpIcon className="w-6 h-6 text-gray-600" />
                                ) : (
                                    <ChevronDownIcon className="w-6 h-6 text-gray-600" />
                                )}
                            </button>

                            {/* ========== BODY ========== */}
                            {isOpen && (
                                <div className="px-6 pb-4 border-t bg-white">
                                    <ul className="space-y-5 mt-4">
                                        {items
                                            .filter((it) => it.ScheduleID === day.ScheduleID)
                                            .sort((a, b) => a.SortOrder - b.SortOrder)
                                            .map((it) => (
                                                <li
                                                    key={it.ItemID}
                                                    className="text-sm text-gray-700 border-b pb-4"
                                                >
                                                    {/* TIME + ACTIVITY */}
                                                    <div className="flex justify-between">
                                                        <span className="font-semibold text-blue-700">
                                                            {it.TimeInfo}
                                                        </span>
                                                        <span className="text-xs text-gray-500">
                                                            Activity #{it.SortOrder}
                                                        </span>
                                                    </div>

                                                    <p className="mt-1 leading-relaxed">
                                                        {it.Activity}
                                                    </p>

                                                    {/* PLACE */}
                                                    {it.PlaceName && (
                                                        <p className="text-gray-600 mt-1">
                                                            📍 <span className="font-medium">{it.PlaceName}</span>
                                                            {it.PlaceAddress && (
                                                                <span className="text-gray-500">
                                                                    {" "}
                                                                    – {it.PlaceAddress}
                                                                </span>
                                                            )}
                                                        </p>
                                                    )}

                                                    {/* TRANSPORTATION */}
                                                    {it.TransportationID && (
                                                        <p className="mt-1 text-xs text-gray-500">
                                                            🚗 Transport:{" "}
                                                            <span className="font-medium text-gray-700">
                                                                {getTransportName(it.TransportationID)}
                                                            </span>{" "}
                                                            ({getTransportDesc(it.TransportationID)})
                                                        </p>
                                                    )}

                                                    {/* COST */}
                                                    {it.Cost > 0 && (
                                                        <p className="text-xs text-green-700 mt-1">
                                                            💲 Extra Cost:{" "}
                                                            <span className="font-semibold">
                                                                {it.Cost.toLocaleString()} VND
                                                            </span>
                                                        </p>
                                                    )}

                                                    {/* IMAGE */}
                                                    {it.ImageUrl && (
                                                        <img
                                                            src={it.ImageUrl}
                                                            alt={it.PlaceName}
                                                            className="mt-3 w-full h-40 object-cover rounded-lg shadow"
                                                        />
                                                    )}
                                                </li>
                                            ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </section>
    );
}
