import {
  CheckCircleIcon,
  XCircleIcon,
  ExclamationTriangleIcon,
  InformationCircleIcon,
  ClipboardDocumentListIcon,
  ArrowPathIcon,
  BanknotesIcon,
} from "@heroicons/react/24/outline";

export default function TourImportantNotes() {
  return (
    <section className="max-w-5xl mx-auto mt-12 space-y-8">
      {/* Title + Intro */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">
          Important Information – East2West Tours & Travels
        </h2>
        <p className="mt-2 text-sm text-gray-600 leading-relaxed">
          Please read the following notes carefully before confirming your
          package tour with East2West Tours and Travels. Our aim is to provide
          transparent information so that your holiday experience is safe,
          comfortable and stress-free.
        </p>
      </div>

      {/* ====== TOUR INCLUDES / EXCLUDES ====== */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Includes */}
        <div className="bg-white rounded-xl border shadow-sm p-6">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircleIcon className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Tour Includes
            </h3>
          </div>
          <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
            <li>
              Air-conditioned transportation for airport transfers and sightseeing
              as per the itinerary.
            </li>
            <li>
              Meals as per the program, planned according to local cuisine
              (breakfast, lunch and dinner where specified).
            </li>
            <li>
              Hotel accommodation in standard twin/double sharing rooms, or
              equivalent category.
            </li>
            <li>Entrance tickets and sightseeing fees as mentioned in the itinerary.</li>
            <li>
              Professional, English-speaking tour guide to escort the group as
              per program.
            </li>
            <li>Complimentary East2West travel cap or similar souvenir.</li>
            <li>
              1 bottle of drinking water per person per day during sightseeing
              and transfers.
            </li>
            <li>
              Travel insurance with coverage up to a predefined limit, subject to
              the terms and conditions of the insurance provider.
            </li>
            <li>All applicable government taxes (including VAT where applicable).</li>
          </ul>
        </div>

        {/* Excludes */}
        <div className="bg-white rounded-xl border shadow-sm p-6">
          <div className="flex items-center gap-2 mb-4">
            <XCircleIcon className="h-6 w-6 text-red-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Tour Excludes
            </h3>
          </div>
          <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
            <li>
              Tips/gratuities for drivers, guides and hotel staff (unless clearly
              mentioned as included).
            </li>
            <li>
              Personal expenses such as laundry, telephone calls, mini-bar, room
              service, and drinks during meals.
            </li>
            <li>
              Optional tours, activities or services not specifically mentioned
              in the itinerary.
            </li>
            <li>
              Early check-in or late check-out at hotels (subject to availability
              and additional charges).
            </li>
            <li>Any other items not explicitly listed under “Tour Includes”.</li>
          </ul>
        </div>
      </div>

      {/* ====== GENERAL IMPORTANT NOTES ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <InformationCircleIcon className="h-6 w-6 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            General Important Notes
          </h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
          <li>
            Before registration, please read the full program, price, inclusions
            and exclusions carefully.
          </li>
          <li>
            Guests aged 70 years or above, or guests with special needs, are
            required to travel with an accompanying family member and must be
            medically fit to join the tour.
          </li>
          <li>
            The sequence of sightseeing may be adjusted depending on local
            conditions, but all mentioned places will be covered as far as
            possible.
          </li>
          <li>
            Standard hotel check-in time is after 14:00 and check-out is before
            12:00, unless otherwise specified in the program.
          </li>
          <li>
            In case of force majeure (such as weather conditions, natural
            disasters, strikes, war, epidemics, airline technical issues or
            cancellations), East2West will refund the remaining value of the
            services not used after deducting all incurred service costs. No
            further compensation will be paid.
          </li>
          <li>
            According to airline regulations, pregnant passengers from 32 weeks
            or more are generally not accepted on domestic flights; please check
            with the airline in advance.
          </li>
        </ul>
      </div>

      {/* ====== FLIGHT NOTES ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <ExclamationTriangleIcon className="h-6 w-6 text-amber-500" />
          <h3 className="text-lg font-semibold text-gray-900">
            Air Travel & Airport Guidelines
          </h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
          <li>
            When booking a tour including flights, please provide full and
            correct names exactly as per passport/ID card. Any correction may
            require re-issuing the ticket with airline penalties.
          </li>
          <li>
            Flight schedules are controlled by the airlines and are subject to
            change without prior notice.
          </li>
          <li>
            Guests are requested to arrive at the airport at least{" "}
            <span className="font-semibold">120 minutes</span> before departure
            for domestic flights (or as specified in your travel documents).
          </li>
          <li>
            After check-in, please keep your boarding pass carefully and be at
            the gate on time. East2West is not responsible for missed flights
            due to late arrival at the gate or loss of boarding passes.
          </li>
        </ul>
      </div>

      {/* ====== BAGGAGE ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <ClipboardDocumentListIcon className="h-6 w-6 text-indigo-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Baggage & Luggage Notes
          </h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
          <li>
            Please label your luggage clearly with your full name and contact
            details.
          </li>
          <li>
            Always collect and keep your baggage tag stubs after check-in for
            verification in case of loss.
          </li>
          <li>
            Do not place valuables such as cash, jewellery, important documents,
            laptops or cameras in checked-in luggage. Use hand luggage for such
            items.
          </li>
          <li>
            Avoid packing fragile items (glass bottles, ceramics, electronics,
            etc.) in checked-in baggage.
          </li>
          <li>
            Items with strong odours such as fish sauce, durian or similar are
            generally not accepted in checked-in baggage by airlines.
          </li>
        </ul>
      </div>

      {/* ====== DOCUMENTS ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <ClipboardDocumentListIcon className="h-6 w-6 text-emerald-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Required Travel Documents
          </h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
          <li>
            Adult guests (14 years and above) must carry a valid Passport or
            National ID card. Overseas guests may need a valid visa depending on
            nationality and destination.
          </li>
          <li>
            Children under 14 years must carry a Birth Certificate or Passport.
          </li>
          <li>
            Infants without a birth certificate must present a hospital Birth
            Certificate/Medical Certificate.
          </li>
          <li>
            Children travelling without parents must present a notarized letter
            of authorization from their legal guardian, as per local regulations.
          </li>
          <li>
            All documents must be valid, unexpired and with a clear photograph,
            except birth certificates as per airline rules.
          </li>
        </ul>
      </div>

      {/* ====== CHANGE / CANCEL ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <ArrowPathIcon className="h-6 w-6 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Changes & Cancellations
          </h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
          <li>
            Cancellation timelines are calculated based on working days only and
            do not include Saturdays, Sundays or public holidays.
          </li>
          <li>
            Any request to change or cancel the tour must be submitted directly
            at our office or via official written communication as per company
            policy. Phone-only requests may not be accepted.
          </li>
          <li>
            Refunds (if applicable) will be processed after deducting all
            non-refundable service charges such as airline tickets, deposits
            paid to hotels and other local suppliers.
          </li>
        </ul>
      </div>

      {/* ====== PAYMENT & PENALTIES ====== */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <BanknotesIcon className="h-6 w-6 text-teal-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Booking, Payment & Cancellation Fees
          </h3>
        </div>
        <div className="space-y-3 text-sm text-gray-700">
          <p className="font-semibold">Registration & Payment:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>
              Payment can be made by cash or bank transfer to East2West Tours
              and Travels.
            </li>
            <li>
              <span className="font-medium">Deposit (1st payment):</span> 50% of
              the total tour price at the time of booking.
            </li>
            <li>
              <span className="font-medium">Balance (2nd payment):</span> 50%
              remaining amount to be settled at least 7 days prior to departure.
            </li>
          </ul>

          <p className="mt-4 font-semibold">Cancellation Fees (per person):</p>
          <ul className="list-disc list-inside space-y-1">
            <li>
              After deposit is paid and before 30 days to departure:{" "}
              <span className="font-medium">50% of tour price</span>.
            </li>
            <li>
              From 30 to 15 days before departure:{" "}
              <span className="font-medium">60% of tour price</span>.
            </li>
            <li>
              From 14 to 7 days before departure:{" "}
              <span className="font-medium">80% of tour price</span>.
            </li>
            <li>
              Within 7 days prior to departure or no-show:{" "}
              <span className="font-medium">100% of tour price</span>.
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
