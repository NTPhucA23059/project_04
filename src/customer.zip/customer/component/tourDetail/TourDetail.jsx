import { useState } from "react";
import { StarIcon } from "@heroicons/react/20/solid";
import ReviewModal from "./ReviewModal";
import TourImportantNotesVI from "./TourImportantNotesVI";
import {
    mockTourSchedules,
    mockTourScheduleItems,
} from "../data/mockData";
import TourScheduleAccordion from "./TourScheduleAccordion";

export default function TourDetail({ tour, details, images, category, season, reviews }) {
    const [showModal, setShowModal] = useState(false);
    const schedules = mockTourSchedules.filter(
        s => s.TourDetailID === details?.TourDetailID
    );

    const avgRating = reviews.length
        ? (
            reviews.reduce((sum, r) => sum + r.Rating, 0) / reviews.length
        ).toFixed(1)
        : "0.0";

    return (
        <div className="bg-white">
            {/* ---------------- Breadcrumb ---------------- */}
            <nav aria-label="Breadcrumb" className="pt-6">
                <ol className="mx-auto flex max-w-7xl items-center space-x-2 px-4">
                    <li>
                        <a href="/tours" className="text-sm font-medium text-gray-500 hover:text-orange-600">
                            Tours
                        </a>
                    </li>
                    <li>
                        <svg fill="currentColor" width={14} height={20} className="text-gray-400">
                            <path d="M5.697 4.34L8.98 16.532h1.327L7.025 4.341H5.697z" />
                        </svg>
                    </li>
                    <li className="text-sm font-medium text-gray-900">{tour?.TourName}</li>
                </ol>
            </nav>

            {/* ---------------- Gallery ---------------- */}
            <div className="mx-auto mt-6 max-w-7xl lg:grid lg:grid-cols-3 lg:gap-8 px-4">
                <div className="row-span-2 aspect-[3/4] w-full rounded-xl bg-gray-200 flex items-center justify-center overflow-hidden">
                    {tour?.TourImg ? (
                        <img src={tour.TourImg} className="w-full h-full object-cover" />
                    ) : (
                        <span className="text-gray-500">No Image</span>
                    )}
                </div>

                {images.slice(0, 4).map((img, i) => (
                    <div
                        key={i}
                        className="aspect-[3/2] w-full rounded-xl bg-gray-200 flex items-center justify-center overflow-hidden"
                    >
                        {img.ImageUrl ? (
                            <img src={img.ImageUrl} alt={img.Caption} className="w-full h-full object-cover" />
                        ) : (
                            <span className="text-gray-500">{img.Caption || "No Image"}</span>
                        )}
                    </div>
                ))}
            </div>

            {/* ---------------- Main Info ---------------- */}
            <div className="mx-auto max-w-7xl px-4 py-12 lg:grid lg:grid-cols-3 lg:gap-8">

                {/* ------------ LEFT SIDE ------------ */}
                <div className="lg:col-span-2 lg:pr-8">
                    <h1 className="text-3xl font-bold text-gray-900">{tour?.TourName}</h1>

                    <p className="mt-1 text-gray-600">Tour Code: {tour?.TourCode}</p>
                    <p className="mt-1 text-gray-600">Category: {category?.CategoryName}</p>
                    <p className="mt-1 text-gray-600">Country: {tour?.Nation}</p>

                    <p className="mt-6 text-gray-700">{tour?.TourDescription}</p>

                    {/* Tour Info */}
                    {details && (
                        <div className="mt-10">
                            <h2 className="text-xl font-bold">Tour Information</h2>
                            <p className="mt-4 text-gray-700">{details.TourDetailDescription}</p>
                        </div>
                    )}

                    {/* Season */}
                    {season && (
                        <div className="mt-8 border-l-4 border-orange-500 pl-4">
                            <h3 className="text-lg font-semibold">Season: {season.SeasonName}</h3>
                            <p className="text-gray-600">{season.Description}</p>
                        </div>
                    )}

                    {/* Highlights */}
                    <div className="mt-10">
                        <h3 className="text-lg font-semibold">Highlights</h3>
                        <ul className="list-disc pl-6 mt-3 space-y-1 text-gray-700">
                            <li>Flight tickets + hotel included</li>
                            <li>Popular sightseeing attractions</li>
                            <li>Transportation & tour guide</li>
                            <li>Travel insurance included</li>
                        </ul>
                    </div>


                </div>

                {/* ------------ BOOKING BOX ------------ */}
                {details && (
                    <div className="mt-10 lg:mt-0">
                        <div className="border rounded-xl p-6 shadow-md bg-orange-50">

                            <p className="text-3xl font-bold text-orange-600">
                                ${Number(details.UnitPrice).toLocaleString()}
                            </p>

                            <div className="mt-5 text-gray-700 text-sm space-y-1">
                                <p><strong>Start:</strong> {new Date(details.DepartureDate).toLocaleDateString()}</p>
                                <p><strong>End:</strong> {new Date(details.ArrivalDate).toLocaleDateString()}</p>
                                <p><strong>From:</strong> {details.FromLocation}</p>
                                <p><strong>To:</strong> {details.ToLocation}</p>
                                <p><strong>Guests:</strong> {details.NumberOfGuests}</p>
                                <p><strong>Booked:</strong> {details.BookedSeat}</p>
                                <p><strong>Available:</strong> {details.NumberOfGuests - details.BookedSeat}</p>
                            </div>

                            <button className="mt-8 w-full bg-orange-600 hover:bg-orange-700 text-white font-semibold py-3 rounded-lg transition">
                                Book This Tour
                            </button>
                        </div>
                    </div>
                )}
            </div>

            <div className="mx-auto max-w-7xl px-4">
                <TourScheduleAccordion
                    schedules={schedules}
                    items={mockTourScheduleItems}
                />
            </div>
            {/* ====== IMPORTANT NOTES FULL WIDTH ====== */}
            <div className="mx-auto max-w-7xl px-4 mt-12">
                <TourImportantNotesVI />
                {/* -------- MODAL -------- */}
                <ReviewModal
                    show={showModal}
                    onClose={() => setShowModal(false)}
                    reviews={reviews}
                />
                {/* ---------------- REVIEWS PRO ---------------- */}
                <div className="mt-14">
                    <h3 className="text-2xl font-bold mb-6">Customer Reviews</h3>

                    {/* AVG */}
                    <div className="flex items-center gap-4 mb-8">
                        <div className="text-center">
                            <p className="text-4xl font-bold text-orange-600">{avgRating}</p>
                            <p className="text-sm text-gray-600">{reviews.length} reviews</p>
                        </div>

                        <div className="flex text-yellow-500">
                            {Array(Math.round(avgRating))
                                .fill(0)
                                .map((_, i) => (
                                    <StarIcon key={i} className="h-7 w-7" />
                                ))}
                        </div>
                    </div>

                    {/* BREAKDOWN (mỗi sao một màu) */}
                    <div className="space-y-2 mb-10">
                        {[5, 4, 3, 2, 1].map((star) => {
                            const count = reviews.filter((r) => r.Rating === star).length;
                            const percent = Math.round((count / reviews.length) * 100) || 0;

                            const colors = {
                                5: "bg-green-500",
                                4: "bg-blue-500",
                                3: "bg-yellow-400",
                                2: "bg-orange-500",
                                1: "bg-red-500",
                            };

                            return (
                                <div key={star} className="flex items-center gap-3">
                                    <span className="w-10 text-sm">{star} ★</span>

                                    <div className="flex-1 bg-gray-200 rounded-full h-3">
                                        <div
                                            className={`h-3 rounded-full ${colors[star]}`}
                                            style={{ width: `${percent}%` }}
                                        />
                                    </div>

                                    <span className="w-12 text-right text-sm text-gray-600">
                                        {percent}%
                                    </span>
                                </div>
                            );
                        })}
                    </div>


                    {/* LIST (5 items) */}
                    <div className="space-y-8">
                        {reviews.slice(0, 5).map((r) => (
                            <div key={r.ReviewID} className="pb-6 border-b">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-full bg-orange-200 flex items-center justify-center text-orange-700 font-bold">
                                        {`U${r.AccountID}`}
                                    </div>

                                    <div>
                                        <p className="font-semibold">User {r.AccountID}</p>

                                        <div className="flex text-yellow-500">
                                            {Array(r.Rating)
                                                .fill(0)
                                                .map((_, i) => (
                                                    <StarIcon key={i} className="h-5 w-5" />
                                                ))}
                                        </div>
                                    </div>
                                </div>

                                <p className="text-gray-700">{r.Comment}</p>

                                <p className="text-xs text-gray-500 mt-1">
                                    {new Date(r.CreatedAt).toLocaleDateString()}
                                </p>
                            </div>
                        ))}
                    </div>

                    {/* Show all reviews */}
                    {reviews.length > 5 && (
                        <button
                            className="mt-6 text-orange-600 font-semibold hover:underline"
                            onClick={() => setShowModal(true)}
                        >
                            View all reviews
                        </button>
                    )}
                </div>
            </div>

        </div>
    );
}
