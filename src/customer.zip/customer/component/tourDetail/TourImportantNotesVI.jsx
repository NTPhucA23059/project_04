import {
    CheckCircleIcon,
    XCircleIcon,
    ExclamationTriangleIcon,
    InformationCircleIcon,
    ClipboardDocumentListIcon,
    ArrowPathIcon,
    BanknotesIcon,
} from "@heroicons/react/24/outline";

export default function TourImportantNotesVI() {
    return (
        <section className="max-w-7xl mx-auto px-4 mt-12 space-y-8">
            {/* ===== GIỚI THIỆU ===== */}
            <div>
                <h2 className="text-2xl font-bold text-gray-900">
                    Lưu Ý Quan Trọng Khi Tham Gia Tour
                </h2>
                <p className="mt-2 text-sm text-gray-600 leading-relaxed">
                    Quý khách vui lòng đọc kỹ các thông tin sau trước khi đăng ký tour.
                    Điều này giúp chuyến đi được diễn ra suôn sẻ, an toàn và đảm bảo quyền
                    lợi của Quý khách trong suốt hành trình.
                </p>
            </div>

            {/* ===== TOUR BAO GỒM / KHÔNG BAO GỒM ===== */}
            <div className="grid gap-6 lg:grid-cols-2">
                {/* === Bao gồm === */}
                <div className="bg-white rounded-xl border shadow-sm p-6">
                    <div className="flex items-center gap-2 mb-4">
                        <CheckCircleIcon className="h-6 w-6 text-green-600" />
                        <h3 className="text-lg font-semibold text-gray-900">Tour Bao Gồm</h3>
                    </div>

                    <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                        <li>
                            Xe vận chuyển máy lạnh đưa đón Quý khách theo chương trình tour.
                        </li>
                        <li>
                            Các bữa ăn theo chương trình, thay đổi món theo ẩm thực địa
                            phương.
                        </li>
                        <li>
                            03 bữa sáng (01 bữa nhà hàng + 02 bữa tại khách sạn) và 05 bữa
                            chính.
                        </li>
                        <li>
                            Khách sạn tiêu chuẩn 2 khách/phòng (hoặc 3 khách/phòng nếu ghép).
                        </li>
                        <li>Vé tham quan theo chương trình.</li>
                        <li>Hướng dẫn viên nhiệt tình, vui vẻ, kinh nghiệm.</li>
                        <li>Quà tặng: nón du lịch.</li>
                        <li>Khăn lạnh, nước uống 01 khăn + 01 chai/ngày.</li>
                        <li>
                            Bảo hiểm du lịch mức bồi thường tối đa 100.000.000đ/người (theo quy
                            định của bảo hiểm Hàng Không).
                        </li>
                        <li>Thuế VAT.</li>
                    </ul>
                </div>

                {/* === Không bao gồm === */}
                <div className="bg-white rounded-xl border shadow-sm p-6">
                    <div className="flex items-center gap-2 mb-4">
                        <XCircleIcon className="h-6 w-6 text-red-600" />
                        <h3 className="text-lg font-semibold text-gray-900">
                            Tour Không Bao Gồm
                        </h3>
                    </div>

                    <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                        <li>Tiền tip dành cho tài xế và hướng dẫn viên.</li>
                        <li>
                            Chi phí cá nhân: Giặt ủi, điện thoại, minibar, thức uống trong bữa
                            ăn, dịch vụ phòng.
                        </li>
                        <li>Các chi phí ngoài chương trình.</li>
                    </ul>
                </div>
            </div>

            {/* ===== MỘT SỐ ĐIỂM LƯU Ý ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <InformationCircleIcon className="h-6 w-6 text-blue-600" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Một Số Điểm Lưu Ý
                    </h3>
                </div>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>Quý khách vui lòng đọc kỹ chương trình và giá tour trước khi đăng ký.</li>
                    <li>
                        Quý khách từ 70 tuổi trở lên hoặc người khuyết tật phải có người thân
                        đi cùng và cam kết đủ sức khỏe để tham gia tour.
                    </li>
                    <li>
                        Thứ tự điểm tham quan có thể thay đổi tùy thực tế nhưng vẫn đảm bảo
                        đầy đủ chương trình.
                    </li>
                    <li>
                        Giờ nhận phòng khách sạn sau 14:00 và trả phòng trước 12:00 (trừ trường
                        hợp đặc biệt).
                    </li>
                    <li>
                        Trường hợp bất khả kháng (thời tiết, thiên tai, đình công, dịch bệnh,
                        hủy chuyến bay…), công ty sẽ hoàn trả chi phí sau khi trừ các khoản
                        đã phát sinh, không bồi thường thêm.
                    </li>
                    <li>
                        Hãng hàng không từ chối khách mang thai từ 32 tuần trở lên khi bay nội
                        địa.
                    </li>
                </ul>
            </div>

            {/* ===== LƯU Ý KHI ĐI MÁY BAY ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <ExclamationTriangleIcon className="h-6 w-6 text-amber-500" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Lưu Ý Khi Tham Gia Tour Bằng Đường Hàng Không
                    </h3>
                </div>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>
                        Cung cấp tên chính xác theo CCCD/Hộ chiếu khi đăng ký. Sai tên phải
                        chịu phí đổi vé theo quy định hãng bay.
                    </li>
                    <li>Giờ bay có thể thay đổi theo điều hành của hãng hàng không.</li>
                    <li>Vui lòng có mặt tại sân bay trước 120 phút.</li>
                    <li>
                        Giữ thẻ lên máy bay cẩn thận. Mất thẻ hoặc trễ giờ cổng lên máy bay →
                        khách tự chịu trách nhiệm.
                    </li>
                </ul>
            </div>

            {/* ===== HÀNH LÝ ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <ClipboardDocumentListIcon className="h-6 w-6 text-indigo-600" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Hành Lý Ký Gửi & Lưu Ý
                    </h3>
                </div>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>Ghi rõ tên và địa chỉ trên thẻ hành lý.</li>
                    <li>Giữ cuống thẻ hành lý sau khi gửi.</li>
                    <li>
                        Không để đồ quý giá (tiền, vàng, laptop…) trong hành lý ký gửi.
                    </li>
                    <li>Không để đồ dễ vỡ trong hành lý ký gửi.</li>
                    <li>
                        Không mang theo các vật có mùi mạnh như nước mắm, sầu riêng trong hành
                        lý ký gửi.
                    </li>
                </ul>
            </div>

            {/* ===== GIẤY TỜ CẦN THIẾT ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <ClipboardDocumentListIcon className="h-6 w-6 text-emerald-600" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Giấy Tờ Cần Thiết Khi Đi Du Lịch
                    </h3>
                </div>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>
                        Người lớn mang theo CCCD/Hộ chiếu còn hạn, có ảnh đóng dấu giáp lai.
                    </li>
                    <li>Trẻ em dưới 14 tuổi mang giấy khai sinh/hộ chiếu.</li>
                    <li>Trẻ dưới 1 tháng tuổi phải có giấy chứng sinh.</li>
                    <li>
                        Trẻ em không đi cùng cha mẹ cần giấy ủy quyền có xác nhận công an.
                    </li>
                    <li>
                        Giấy tờ phải còn thời hạn sử dụng và đúng quy định của hãng hàng
                        không.
                    </li>
                </ul>
            </div>

            {/* ===== CHUYỂN / HỦY TOUR ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <ArrowPathIcon className="h-6 w-6 text-purple-600" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Lưu Ý Khi Chuyển / Huỷ Tour
                    </h3>
                </div>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>
                        Thời gian hủy tour được tính theo ngày làm việc (không tính Thứ 7/Chủ
                        nhật/Lễ Tết).
                    </li>
                    <li>
                        Khi muốn chuyển/hủy tour, Quý khách vui lòng đến trực tiếp văn phòng
                        để làm thủ tục, mang theo Vé Tham Quan hoặc giấy tờ tương ứng.
                    </li>
                </ul>
            </div>

            {/* ===== THANH TOÁN & ĐIỀU KIỆN PHẠT ===== */}
            {/* ===== QUY ĐỊNH HOÀN TIỀN (EAST2WEST) ===== */}
            <div className="bg-white rounded-xl border shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4">
                    <ArrowPathIcon className="h-6 w-6 text-purple-600" />
                    <h3 className="text-lg font-semibold text-gray-900">
                        Quy Định Hoàn Tiền (Refund Rules)
                    </h3>
                </div>

                <p className="text-sm text-gray-700 mb-3">
                    Theo quy định của East2West Tours and Travels, khoản hoàn tiền được áp dụng cho dịch vụ bị hủy dựa trên số ngày còn lại trước khi sử dụng dịch vụ. Tỷ lệ hoàn lại như sau:
                </p>

                <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                    <li>Hủy trước <span className="font-semibold">1 ngày</span>: hoàn <span className="font-semibold text-purple-700">75%</span> giá trị dịch vụ.</li>
                    <li>Hủy trước <span className="font-semibold">2 ngày</span>: hoàn <span className="font-semibold text-purple-700">80%</span>.</li>
                    <li>Hủy trước <span className="font-semibold">3 ngày</span>: hoàn <span className="font-semibold text-purple-700">85%</span>.</li>
                    <li>Hủy trước <span className="font-semibold">4 ngày</span>: hoàn <span className="font-semibold text-purple-700">90%</span>.</li>
                    <li>Hủy trước <span className="font-semibold">5 ngày hoặc nhiều hơn</span>: hoàn <span className="font-semibold text-purple-700">95%</span>.</li>
                </ul>

                <p className="text-xs text-gray-500 mt-3 italic">
                    Lưu ý: Tỷ lệ hoàn tiền áp dụng cho giá trị dịch vụ còn lại, sau khi trừ đi các chi phí đã được triển khai hoặc thanh toán cho đối tác liên quan.
                </p>
            </div>

        </section>
    );
}
