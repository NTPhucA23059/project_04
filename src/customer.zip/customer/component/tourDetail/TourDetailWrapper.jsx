import { useParams } from "react-router-dom";
import {
    tours,
    mockTourDetails,
    mockTourDetailImages,
    mockCategories,
    mockSeasons,
    mockTourReviews
} from "../data/mockData.js";

import TourDetail from "./TourDetail";

export default function TourDetailWrapper() {
    const { id } = useParams();
    const tourId = Number(id);

    const tour = tours.find((t) => t.TourID === tourId);
    const details = mockTourDetails.find((d) => d.TourID === tourId);

    const images = details
        ? mockTourDetailImages.filter((img) => img.TourDetailID === details.TourDetailID)
        : [];

    const category = tour
        ? mockCategories.find((c) => c.CategoryID === tour.CategoryID)
        : null;

    const season = details?.SeasonID
        ? mockSeasons.find((s) => s.SeasonID === details.SeasonID)
        : null;

    const reviews = details
        ? mockTourReviews.filter((r) => r.TourDetailID === details.TourDetailID)
        : [];

    if (!tour) return <p className="p-10 text-red-600">Tour not found.</p>;

    return (
        <TourDetail
            tour={tour}
            details={details}
            images={images}
            category={category}
            season={season}
            reviews={reviews}
        />
    );
}
