import "./profile.css";
import { useState } from "react";
import {
    FaUser,
    FaPhone,
    FaEnvelope,
    FaGlobeAsia,
    FaIdCard,
    FaTransgender,
    FaShoppingBag,
    FaRegHeart,
    FaMapMarkerAlt,
    FaLock
} from "react-icons/fa";

export default function Profile() {
    const [showEditModal, setShowEditModal] = useState(false);
    const [showChangePassword, setShowChangePassword] = useState(false);
    const [pwError, setPwError] = useState("");
    const [editErrors, setEditErrors] = useState({});

    const [user] = useState({
        FullName: "Nguyen Van A",
        Username: "nguyenvana",
        Email: "vana@gmail.com",
        Phone: "0912345678",
        Nationality: "Vietnam",
        CitizenCard: "0123456789",
        Gender: "Male",
    });

    // ---------------- PASSWORD VALIDATION (OWASP / International) ---------------- //
    const validatePassword = (newPass, confirmPass, oldPass) => {
        if (newPass !== confirmPass) return "Passwords do not match.";
        if (newPass === oldPass) return "New password must be different from the old password.";
        if (newPass.length < 8) return "Password must be at least 8 characters long.";
        if (!/[a-z]/.test(newPass)) return "Password must contain at least one lowercase letter.";
        if (!/[A-Z]/.test(newPass)) return "Password must contain at least one uppercase letter.";
        if (!/[0-9]/.test(newPass)) return "Password must contain at least one number.";
        if (!/[!@#$%^&*(),.?":{}|<>]/.test(newPass))
            return "Password must contain at least one special character.";

        return "";
    };

    // ---------------- PROFILE VALIDATION ---------------- //
    const validateProfile = (data) => {
        let errors = {};

        if (!data.FullName.trim())
            errors.FullName = "Full name is required.";
        else if (!/^[a-zA-Z\s]+$/.test(data.FullName))
            errors.FullName = "Full name must contain only letters.";

        if (!data.Email.trim())
            errors.Email = "Email is required.";
        else if (!/^\S+@\S+\.\S+$/.test(data.Email))
            errors.Email = "Invalid email format.";

        if (!data.Phone.trim())
            errors.Phone = "Phone number is required.";
        else if (!/^[0-9]{10}$/.test(data.Phone))
            errors.Phone = "Phone number must be exactly 10 digits.";

        if (!data.Nationality.trim())
            errors.Nationality = "Nationality is required.";

        if (!data.CitizenCard.trim())
            errors.CitizenCard = "Citizen ID is required.";
        else if (!/^[0-9]{9,12}$/.test(data.CitizenCard))
            errors.CitizenCard = "Citizen ID must be 9–12 digits.";

        if (!data.Gender)
            errors.Gender = "Gender is required.";

        return errors;
    };

    return (
        <div className="profile-container">

            {/* BREADCRUMB */}
            <div className="profile-breadcrumb">
                Home / Account / <span>Profile</span>
            </div>

            <div className="profile-layout">

                {/* SIDEBAR */}
                <aside className="profile-sidebar">
                    <div className="profile-sidebar-header">
                        <div className="profile-avatar-wrapper">
                            <img src="/default-avatar.png" className="profile-avatar" alt="avatar" />
                        </div>

                        <div>
                            <h2 className="profile-sidebar-name">{user.FullName}</h2>
                            <p className="profile-sidebar-username">@{user.Username}</p>
                        </div>
                    </div>

                    <button className="avatar-upload-btn">Change Avatar</button>

                    <nav className="profile-sidebar-menu">

                        <button className="sidebar-link active">
                            <FaUser className="sidebar-icon" />
                            <span>Account Details</span>
                        </button>

                        <button className="sidebar-link">
                            <FaShoppingBag className="sidebar-icon" />
                            <span>Orders</span>
                        </button>

                        <button className="sidebar-link">
                            <FaRegHeart className="sidebar-icon" />
                            <span>Wishlist</span>
                        </button>

                        <button className="sidebar-link">
                            <FaMapMarkerAlt className="sidebar-icon" />
                            <span>Shipping Address</span>
                        </button>

                        <button
                            className="sidebar-link"
                            onClick={() => setShowChangePassword(true)}
                        >
                            <FaLock className="sidebar-icon" />
                            <span>Change Password</span>
                        </button>
                    </nav>
                </aside>

                {/* MAIN CONTENT */}
                <main className="profile-main">

                    {/* ACCOUNT INFO */}
                    <div className="profile-card">
                        <div className="profile-card-header">
                            <h3 className="profile-section-title">Account Details</h3>
                            <button
                                className="edit-btn"
                                onClick={() => setShowEditModal(true)}
                            >
                                Edit
                            </button>
                        </div>

                        <div className="profile-info-grid">
                            {[
                                { icon: <FaUser />, label: "Full Name", value: user.FullName },
                                { icon: <FaEnvelope />, label: "Email", value: user.Email },
                                { icon: <FaPhone />, label: "Phone", value: user.Phone },
                                { icon: <FaTransgender />, label: "Gender", value: user.Gender },
                                { icon: <FaGlobeAsia />, label: "Nationality", value: user.Nationality },
                                { icon: <FaIdCard />, label: "Citizen ID", value: user.CitizenCard }
                            ].map((item, i) => (
                                <div key={i} className="profile-info-item">
                                    <div className="profile-icon">{item.icon}</div>
                                    <div>
                                        <p className="label">{item.label}</p>
                                        <p className="value">{item.value}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* STATS */}
                    <div className="profile-stats">
                        <div className="stat-item"><h4>12</h4><p>Orders</p></div>
                        <div className="stat-item"><h4>4</h4><p>Reviews</p></div>
                        <div className="stat-item"><h4>250</h4><p>Points</p></div>
                    </div>
                </main>
            </div>

            {/* =====================================
                       EDIT PROFILE - MODAL
            ====================================== */}
            {showEditModal && (
                <div className="modal-overlay" onClick={() => setShowEditModal(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>

                        <div className="modal-header">
                            <h3>Edit Profile</h3>
                            <button className="modal-close" onClick={() => setShowEditModal(false)}>×</button>
                        </div>

                        <form
                            className="modal-form-grid"
                            onSubmit={(e) => {
                                e.preventDefault();

                                const formData = {
                                    FullName: e.target.FullName.value,
                                    Email: e.target.Email.value,
                                    Phone: e.target.Phone.value,
                                    Nationality: e.target.Nationality.value,
                                    CitizenCard: e.target.CitizenCard.value,
                                    Gender: e.target.Gender.value,
                                };

                                const errors = validateProfile(formData);
                                setEditErrors(errors);

                                if (Object.keys(errors).length > 0) return;

                                alert("Profile updated successfully!");
                                setShowEditModal(false);
                            }}
                        >

                            {/* FULL NAME */}
                            <div className="modal-form-group">
                                <label>Full Name</label>
                                <input type="text" name="FullName" defaultValue={user.FullName} />
                                {editErrors.FullName && <p className="error-text">{editErrors.FullName}</p>}
                            </div>

                            {/* EMAIL */}
                            <div className="modal-form-group">
                                <label>Email</label>
                                <input type="email" name="Email" defaultValue={user.Email} />
                                {editErrors.Email && <p className="error-text">{editErrors.Email}</p>}
                            </div>

                            {/* PHONE */}
                            <div className="modal-form-group">
                                <label>Phone</label>
                                <input type="text" name="Phone" defaultValue={user.Phone} />
                                {editErrors.Phone && <p className="error-text">{editErrors.Phone}</p>}
                            </div>

                            {/* NATIONALITY */}
                            <div className="modal-form-group">
                                <label>Nationality</label>
                                <input type="text" name="Nationality" defaultValue={user.Nationality} />
                                {editErrors.Nationality && <p className="error-text">{editErrors.Nationality}</p>}
                            </div>

                            {/* CITIZEN ID */}
                            <div className="modal-form-group">
                                <label>Citizen ID</label>
                                <input type="text" name="CitizenCard" defaultValue={user.CitizenCard} />
                                {editErrors.CitizenCard && <p className="error-text">{editErrors.CitizenCard}</p>}
                            </div>

                            {/* GENDER */}
                            <div className="modal-form-group">
                                <label>Gender</label>
                                <select name="Gender" defaultValue={user.Gender}>
                                    <option value="">-- Choose Gender --</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                                {editErrors.Gender && <p className="error-text">{editErrors.Gender}</p>}
                            </div>

                            <button className="modal-save-btn">Save Changes</button>
                        </form>

                    </div>
                </div>
            )}

            {/* =====================================
                       CHANGE PASSWORD - MODAL
            ====================================== */}
            {showChangePassword && (
                <div className="modal-overlay" onClick={() => setShowChangePassword(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>

                        <div className="modal-header">
                            <h3>Change Password</h3>
                            <button className="modal-close" onClick={() => setShowChangePassword(false)}>×</button>
                        </div>

                        <form
                            className="modal-form-grid"
                            onSubmit={(e) => {
                                e.preventDefault();

                                const oldPass = e.target.oldPass.value;
                                const newPass = e.target.newPass.value;
                                const confirmPass = e.target.confirmPass.value;

                                const error = validatePassword(newPass, confirmPass, oldPass);
                                if (error) {
                                    setPwError(error);
                                    return;
                                }

                                setPwError("");
                                alert("Password updated successfully!");
                                setShowChangePassword(false);
                            }}
                        >

                            <div className="modal-form-group">
                                <label>Current Password</label>
                                <input type="password" name="oldPass" required placeholder="Enter current password" />
                            </div>

                            <div className="modal-form-group">
                                <label>New Password</label>
                                <input type="password" name="newPass" required placeholder="Enter new password" />
                            </div>

                            <div className="modal-form-group">
                                <label>Confirm New Password</label>
                                <input type="password" name="confirmPass" required placeholder="Re-enter new password" />
                            </div>

                            {pwError && <p className="error-text">{pwError}</p>}

                            <button className="modal-save-btn">Update Password</button>
                        </form>

                    </div>
                </div>
            )}

        </div>
    );
}
