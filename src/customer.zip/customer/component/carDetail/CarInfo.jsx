import { FaCarSide, FaStar } from "react-icons/fa";

export default function CarInfo({ car, type, reviews }) {
    const avg =
        reviews.length === 0
            ? 0
            : (reviews.reduce((s, r) => s + r.Rating, 0) / reviews.length).toFixed(1);

    return (
        <div className="space-y-3">
            <h1 className="text-3xl font-bold flex items-center gap-2">
                <FaCarSide className="text-orange-600" />
                {car.ModelName}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-2 text-yellow-500">
                <FaStar />
                <span className="font-semibold text-gray-800">{avg}</span>
                <span className="text-gray-500 text-sm">{reviews.length} reviews</span>
            </div>

            {/* Basic info */}
            <div className="text-gray-700 text-sm space-y-1">
                <p><strong>Brand:</strong> {car.Brand}</p>
                <p><strong>Type:</strong> {type?.TypeName}</p>
                <p><strong>Seats:</strong> {car.SeatingCapacity}</p>
                <p><strong>Luggage:</strong> {car.Luggage}</p>
                <p><strong>Fuel:</strong> {car.FuelType}</p>
                <p><strong>Transmission:</strong> {car.Transmission}</p>
                <p><strong>Model year:</strong> {car.ModelYear}</p>
                <p><strong>Plate:</strong> {car.PlateNumber}</p>
            </div>

            <p className="text-gray-700 mt-4">{car.Note}</p>
        </div>
    );
}
