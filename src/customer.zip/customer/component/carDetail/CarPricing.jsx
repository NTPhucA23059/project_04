import { useState } from "react";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/24/solid";
import "./index.css"

export default function CarPricing({ car }) {
    const [open, setOpen] = useState(false);

    return (
        <div className="p-6 bg-white border rounded-xl shadow-lg">
            {/* PRICE */}
            <p className="text-3xl font-bold text-orange-600 mb-4">
                ${(car.DailyRate).toLocaleString()} <span className="text-lg font-medium text-gray-600">/ day</span>
            </p>

            {/* BOOK BUTTON */}
            <button className="w-full py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition font-semibold">
                Book This Car
            </button>

            {/* COLLAPSE HEADER */}
            <button
                onClick={() => setOpen(!open)}
                className="mt-5 w-full flex items-center justify-between text-gray-700 font-semibold py-2"
            >
                <span>Rental Details</span>
                {open ? (
                    <ChevronUpIcon className="w-5 h-5 text-gray-600" />
                ) : (
                    <ChevronDownIcon className="w-5 h-5 text-gray-600" />
                )}
            </button>

            {/* COLLAPSE CONTENT */}
            {open && (
                <div className="mt-2 text-sm animate-fadeIn">
                    {/* INCLUDED */}
                    <p className="text-gray-600 font-semibold mt-3">Included:</p>
                    <ul className="text-gray-700 space-y-1 ml-2">
                        <li>✔ Driver included</li>
                        <li>✔ Fuel included</li>
                    </ul>

                    {/* NOT INCLUDED */}
                    <p className="text-gray-600 font-semibold mt-4">Not Included:</p>
                    <ul className="text-red-600 space-y-1 ml-2">
                        <li>✘ VAT 10%</li>
                        <li>✘ Toll fee</li>
                    </ul>

                    {/* EXTRA FEES */}
                    <p className="text-gray-600 font-semibold mt-4">Extra Fees:</p>
                    <ul className="text-blue-700 space-y-1 ml-2">
                        <li>• $20 / hour (exceeded)</li>
                        <li>• $2 / km (exceeded)</li>
                    </ul>
                </div>
            )}
        </div>
    );
}
