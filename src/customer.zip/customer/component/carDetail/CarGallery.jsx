import { useState } from "react";

export default function CarGallery({ images }) {
    const [main, setMain] = useState(images[0]);

    return (
        <div>
            {/* MAIN IMAGE */}
            <img
                src={main.ImageUrl}
                className="w-full h-[430px] object-cover rounded-xl shadow"
            />

            {/* GALLERY THUMBNAILS */}
            <div className="grid grid-cols-3 gap-4 mt-4">
                {images.slice(0, 3).map((img) => (
                    <img
                        key={img.ImageID}
                        src={img.ImageUrl}
                        onClick={() => setMain(img)}
                        className={`h-36 w-full object-cover rounded-lg cursor-pointer border
                            ${main.ImageID === img.ImageID ? "border-orange-600" : "border-transparent"}
                        `}
                    />
                ))}
            </div>
        </div>
    );
}
