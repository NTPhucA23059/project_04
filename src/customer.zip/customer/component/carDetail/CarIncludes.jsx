export default function CarIncludes() {
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10 mt-[-50px]">
            <div className="p-6 border rounded-xl bg-white shadow">
                <h3 className="text-lg font-semibold mb-3 text-green-600">Included</h3>
                <ul className="list-disc pl-5 text-gray-700 space-y-1">
                    <li>Driver</li>
                    <li>Fuel</li>
                    <li>Car insurance</li>
                </ul>
            </div>

            <div className="p-6 border rounded-xl bg-white shadow">
                <h3 className="text-lg font-semibold mb-3 text-red-600">Not Included</h3>
                <ul className="list-disc pl-5 text-gray-700 space-y-1">
                    <li>VAT 10%</li>
                    <li>Road toll</li>
                    <li>Parking fee</li>
                </ul>
            </div>
        </div>
    );
}
