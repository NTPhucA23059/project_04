export { default as CarGallery } from "./CarGallery";
export { default as CarInfo } from "./CarInfo";
export { default as CarPricing } from "./CarPricing";
export { default as CarIncludes } from "./CarIncludes";
export { default as CarReview } from "./CarReview";

