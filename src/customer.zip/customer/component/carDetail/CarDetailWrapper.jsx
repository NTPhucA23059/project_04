import { useParams } from "react-router-dom";
import {
    cars,
    mockCarTypes,
    mockCarImages,
    mockCarReviews
} from "../../component/data/mockData";

import CarDetail from "./CarDetail";

export default function CarDetailWrapper() {
    const { id } = useParams();
    const carId = Number(id);

    const car = cars.find(c => c.CarID === carId);

    if (!car) return <p className="p-10 text-red-500">Car not found.</p>;

    const type = mockCarTypes.find(t => t.CarTypeID === car.CarTypeID);

    const images = mockCarImages.filter(img => img.CarID === car.CarID);

    const reviews = mockCarReviews.filter(r => r.CarID === car.CarID);

    return (
        <CarDetail
            car={car}
            type={type}
            images={images}
            reviews={reviews}
        />
    );
}
