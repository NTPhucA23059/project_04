"use client";

import { useState } from "react";
import { tours, tourSchedules } from "../../component/data/mockData.js";
import TourCard from "../../component/tour/TourCard";
import SearchBox from "../../component/tour/SearchBox";
import TourFilters from "../../component/tour/TourFilters";

export default function Tours() {
    const ITEMS_PER_PAGE = 6;

    const [page, setPage] = useState(1);
    const [filters, setFilters] = useState({});

    // ---------------------------------------
    // FILTER LOGIC
    // ---------------------------------------
    const applyFilters = (list) => {
        return list.filter(tour => {

            // DESTINATION
            if (filters.destination) {
                const key = filters.destination.toLowerCase();
                const content =
                    `${tour.TourName} ${tour.Nation} ${tour.StartingLocation}`.toLowerCase();
                if (!content.includes(key)) return false;
            }

            // START DATE
            if (filters.startDate) {
                const schedules = tourSchedules[tour.TourID] || [];
                const ok = schedules.some(
                    s => new Date(s.DepartureDate) >= filters.startDate
                );
                if (!ok) return false;
            }

            // DURATION
            if (filters.duration && filters.duration !== "Any") {
                const d = parseInt(tour.Duration);
                if (filters.duration === "1–3 days" && (d < 1 || d > 3)) return false;
                if (filters.duration === "4–7 days" && (d < 4 || d > 7)) return false;
                if (filters.duration === "8–14 days" && (d < 8 || d > 14)) return false;
                if (filters.duration === "15+ days" && d < 15) return false;
            }

            // CATEGORY
            if (filters.category && tour.CategoryID !== filters.category) {
                return false;
            }

            // SEASON
            if (filters.season) {
                const schedules = tourSchedules[tour.TourID] || [];
                const hasSeason = schedules.some(s => s.SeasonID === filters.season);
                if (!hasSeason) return false;
            }

            // BUDGET
            if (filters.budget) {
                const price = tour.Price || tour.PriceFrom;
                if (price < filters.budget.min || price > filters.budget.max) {
                    return false;
                }
            }

            // RATING (Fake)
            if (filters.rating) {
                const fakeRating = Math.floor(Math.random() * 5) + 1;
                if (fakeRating < filters.rating) return false;
            }

            return true;
        });
    };

    const filteredTours = applyFilters(tours);

    // ---------------------------------------
    // PAGINATION
    // ---------------------------------------
    const totalPages = Math.ceil(filteredTours.length / ITEMS_PER_PAGE);
    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const currentTours = filteredTours.slice(startIndex, startIndex + ITEMS_PER_PAGE);

    const goToPage = (p) => {
        if (p >= 1 && p <= totalPages) {
            setPage(p);
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    };

    return (
        <div className="flex flex-col min-h-screen bg-neutral-50">

            {/* Search Bar */}
            <div className="max-w-7xl mx-auto w-full px-4">
                <SearchBox
                    onSearch={(data) => {
                        setFilters(prev => ({ ...prev, ...data }));
                        setPage(1);
                    }}
                />
            </div>

            <div className="flex max-w-7xl mx-auto w-full px-4 mt-6">

                {/* Sidebar Filters */}
                <TourFilters
                    onChange={(data) => {
                        setFilters(prev => ({ ...prev, ...data }));
                        setPage(1);
                    }}
                />

                {/* Tour List */}
                <div className="flex-1 ml-6 space-y-5 pb-10">

                    {currentTours.map(tour => (
                        <TourCard
                            key={tour.TourID}
                            tour={tour}
                            schedule={tourSchedules[tour.TourID] || []}
                        />
                    ))}

                    {currentTours.length === 0 && (
                        <div className="text-center text-neutral-500 py-10">
                            No tours match your filter.
                        </div>
                    )}

                    {/* PAGINATION */}
                    {totalPages > 1 && (
                        <div className="flex items-center justify-center gap-2 mt-6">
                            <button
                                disabled={page === 1}
                                onClick={() => goToPage(page - 1)}
                                className={`px-3 py-1 rounded-lg border text-sm 
                                    ${page === 1 ? "opacity-40" : "hover:bg-primary-100"}`}
                            >
                                Previous
                            </button>

                            {Array.from({ length: totalPages }, (_, i) => i + 1)
                                .map(num => (
                                    <button
                                        key={num}
                                        onClick={() => goToPage(num)}
                                        className={`px-3 py-1 rounded-lg border text-sm
                                            ${page === num
                                                ? "bg-primary-500 text-white"
                                                : "hover:bg-primary-100"
                                            }`}
                                    >
                                        {num}
                                    </button>
                                ))}

                            <button
                                disabled={page === totalPages}
                                onClick={() => goToPage(page + 1)}
                                className={`px-3 py-1 rounded-lg border text-sm
                                    ${page === totalPages ? "opacity-40" : "hover:bg-primary-100"}`}
                            >
                                Next
                            </button>
                        </div>
                    )}

                </div>

            </div>

        </div>
    );
}
