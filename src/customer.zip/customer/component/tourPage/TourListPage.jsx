import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { mockCategories } from "../data/mockData";  // ⬅️ IMPORT CATEGORY LIST

export default function TourListPageVN({ tours = [] }) {
  const [showList, setShowList] = useState(false);
  const [category, setCategory] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // ============================
  //   CATEGORY LIST FROM DB
  // ============================
  const categories = [
    "All",
    ...mockCategories.map(c => c.CategoryName)
  ];

  // ============================
  //   FILTER BY CATEGORY
  // ============================
  const filteredTours =
    category === "All"
      ? tours
      : tours.filter(t => {
        const cat = mockCategories.find(c => c.CategoryID === t.CategoryID);
        return cat?.CategoryName === category;
      });

  // ============================
  //   PAGINATION
  // ============================
  const totalPages = Math.ceil(filteredTours.length / itemsPerPage);

  const paginatedTours = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredTours.slice(start, start + itemsPerPage);
  }, [filteredTours, currentPage]);

  const startIndex = (currentPage - 1) * itemsPerPage;


  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">

        {/* BUTTON SHOW/HIDE */}
        <button
          onClick={() => setShowList(!showList)}
          className="mb-6 px-4 py-2 flex items-center gap-2 bg-primary-400 text-white rounded-full shadow hover:bg-primary-500 transition"
        >
          {showList ? <FaEyeSlash className="text-xl" /> : <FaEye className="text-xl" />}
          <span className="text-sm font-medium">
            {showList ? "Hide Domestic Tours" : "Show Domestic Tours"}
          </span>
        </button>

        {!showList && (
          <p className="text-neutral-500">Click the button above to view the tour list.</p>
        )}

        {/* LIST SECTION */}
        {showList && (
          <>
            <h2 className="text-3xl font-bold text-primary-700 mb-5">
              Domestic Tours
            </h2>

            {/* CATEGORY TABS */}
            <div className="flex gap-8 mb-8 border-b pb-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => {
                    setCategory(cat);
                    setCurrentPage(1);
                  }}
                  className={`text-lg font-medium pb-1 relative
                    ${category === cat
                      ? "text-primary-700"
                      : "text-neutral-500 hover:text-primary-400"
                    }
                  `}
                >
                  {cat}

                  {category === cat && (
                    <span className="absolute left-0 right-0 -bottom-[2px] h-[2px] bg-primary-600"></span>
                  )}
                </button>
              ))}
            </div>

            {/* GRID TOURS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
              {paginatedTours.map((tour) => {
                const cat = mockCategories.find(c => c.CategoryID === tour.CategoryID);
                return (
                  <div
                    key={tour.TourID}
                    className="border rounded-xl shadow p-4 hover:shadow-lg transition"
                  >
                    <img
                      src={tour.TourImg}
                      className="w-full h-56 object-cover rounded-md"
                    />

                    <p className="mt-3 inline-block px-3 py-1 bg-neutral-100 rounded-md text-primary-600 text-sm font-semibold">
                      {cat?.CategoryName}
                    </p>

                    <div className="mt-3">
                      <p className="text-sm text-neutral-500">
                        Duration: {tour.Duration}
                      </p>
                      <h3 className="text-lg font-bold mt-1">{tour.TourName}</h3>

                      <p className="text-sm mt-2">
                        <strong>Tour code: </strong> {tour.TourCode}
                      </p>
                      <p className="text-sm">
                        <strong>Departure from: </strong> {tour.StartingLocation}
                      </p>

                      <div className="mt-4 flex justify-between items-center">
                        <p className="text-xl font-bold text-red-600">
                          ${tour.Price.toLocaleString()}
                        </p>

                        <Link
                          to={`/tours/${tour.TourID}`}
                          className="px-3 py-2 border border-primary-600 text-primary-600 rounded-md hover:bg-primary-50"
                        >
                          View details
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* PAGINATION */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-between items-center">
                <p className="text-sm text-neutral-600">
                  Showing {startIndex + 1} -{" "}
                  {Math.min(startIndex + itemsPerPage, filteredTours.length)} of{" "}
                  {filteredTours.length} tours
                </p>

                <div className="flex gap-2">
                  <button
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className={`px-3 py-1 border rounded-md ${currentPage === 1 ? "opacity-40" : "hover:bg-neutral-200"
                      }`}
                  >
                    Previous
                  </button>

                  {Array.from({ length: totalPages }).map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentPage(i + 1)}
                      className={`w-9 h-9 border rounded-md ${currentPage === i + 1
                        ? "bg-primary-600 text-white"
                        : "hover:bg-neutral-200"
                        }`}
                    >
                      {i + 1}
                    </button>
                  ))}

                  <button
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className={`px-3 py-1 border rounded-md ${currentPage === totalPages ? "opacity-40" : "hover:bg-neutral-200"
                      }`}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
