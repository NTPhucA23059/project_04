"use client";

import { useState } from "react";
import {
    Menu,
    MenuButton,
    MenuItem,
    MenuItems
} from "@headlessui/react";

import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { cars, mockCarTypes } from "../data/mockData";
import CarCard from "./CarCard";

export default function CarListPage() {
    const ITEMS_PER_PAGE = 6;

    const [selectedType, setSelectedType] = useState(null);
    const [selectedBrand, setSelectedBrand] = useState(null);
    const [selectedSeats, setSelectedSeats] = useState(null);
    const [sort, setSort] = useState("default");
    const [page, setPage] = useState(1);

    const brands = [...new Set(cars.map(c => c.Brand))];
    const seats = [...new Set(cars.map(c => c.SeatingCapacity))];

    // ==========================
    // FILTER LOGIC
    // ==========================
    const filteredCars = cars
        .filter(c => (selectedType ? c.CarTypeID === selectedType : true))
        .filter(c => (selectedBrand ? c.Brand === selectedBrand : true))
        .filter(c => (selectedSeats ? c.SeatingCapacity === selectedSeats : true))
        .sort((a, b) => {
            if (sort === "price_asc") return a.DailyRate - b.DailyRate;
            if (sort === "price_desc") return b.DailyRate - a.DailyRate;
            return 0;
        });

    // ==========================
    // PAGINATION
    // ==========================
    const totalPages = Math.ceil(filteredCars.length / ITEMS_PER_PAGE);
    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const currentCars = filteredCars.slice(startIndex, startIndex + ITEMS_PER_PAGE);

    const goToPage = (p) => {
        if (p >= 1 && p <= totalPages) {
            setPage(p);
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    };

    return (
        <div className="bg-neutral-50 py-12 mt-[100px]">

            {/* HEADER */}
            <div className="text-center mb-10">
                <h1 className="text-4xl font-bold text-neutral-900">Car Rentals</h1>
                <p className="text-neutral-500 mt-2">
                    Premium cars for travel, business, and family trips.
                </p>
            </div>

            {/* FILTER BAR */}
            <div className="max-w-7xl mx-auto px-6 flex items-center justify-end gap-6 border-b pb-6">

                <FilterDropdown
                    label="Sort"
                    options={[
                        { label: "Default", value: "default" },
                        { label: "Price: Low to High", value: "price_asc" },
                        { label: "Price: High to Low", value: "price_desc" },
                    ]}
                    selected={sort}
                    onChange={(v) => {
                        setSort(v);
                        setPage(1);
                    }}
                />

                <FilterDropdown
                    label="Category"
                    badge={selectedType ? 1 : 0}
                    options={mockCarTypes.map(t => ({
                        label: t.TypeName,
                        value: t.CarTypeID
                    }))}
                    selected={selectedType}
                    onChange={(v) => {
                        setSelectedType(v === selectedType ? null : v);
                        setPage(1);
                    }}
                />

                <FilterDropdown
                    label="Brand"
                    badge={selectedBrand ? 1 : 0}
                    options={brands.map(b => ({ label: b, value: b }))}
                    selected={selectedBrand}
                    onChange={(v) => {
                        setSelectedBrand(v === selectedBrand ? null : v);
                        setPage(1);
                    }}
                />

                <FilterDropdown
                    label="Seats"
                    badge={selectedSeats ? 1 : 0}
                    options={seats.map(s => ({ label: `${s} seats`, value: s }))}
                    selected={selectedSeats}
                    onChange={(v) => {
                        setSelectedSeats(v === selectedSeats ? null : v);
                        setPage(1);
                    }}
                />

            </div>

            {/* CAR GRID */}
            <div className="max-w-7xl mx-auto px-6 mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {currentCars.map(car => (
                    <CarCard key={car.CarID} car={car} />
                ))}

                {currentCars.length === 0 && (
                    <div className="col-span-full text-center text-neutral-500 py-16">
                        No cars found. Try adjusting filters.
                    </div>
                )}
            </div>

            {/* PAGINATION */}
            {totalPages > 1 && (
                <div className="flex justify-center mt-10 gap-2">

                    {/* Prev */}
                    <button
                        onClick={() => goToPage(page - 1)}
                        disabled={page === 1}
                        className={`px-3 py-1 rounded-lg border text-sm ${
                            page === 1
                                ? "opacity-40 cursor-not-allowed"
                                : "hover:bg-primary-100 hover:border-primary-600"
                        }`}
                    >
                        Previous
                    </button>

                    {/* Numbers */}
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(num => (
                        <button
                            key={num}
                            onClick={() => goToPage(num)}
                            className={`px-3 py-1 rounded-lg border text-sm ${
                                page === num
                                    ? "bg-primary-600 text-white border-primary-600"
                                    : "hover:bg-primary-100 hover:border-primary-600"
                            }`}
                        >
                            {num}
                        </button>
                    ))}

                    {/* Next */}
                    <button
                        onClick={() => goToPage(page + 1)}
                        disabled={page === totalPages}
                        className={`px-3 py-1 rounded-lg border text-sm ${
                            page === totalPages
                                ? "opacity-40 cursor-not-allowed"
                                : "hover:bg-primary-100 hover:border-primary-600"
                        }`}
                    >
                        Next
                    </button>

                </div>
            )}

        </div>
    );
}


/* ===============================
   FILTER DROPDOWN COMPONENT
================================ */
function FilterDropdown({ label, options, selected, onChange, badge }) {
    return (
        <Menu as="div" className="relative inline-block text-left">
            <MenuButton className="flex items-center gap-1 text-neutral-700 hover:text-black">
                {label}
                {badge > 0 && (
                    <span className="px-2 py-0.5 text-xs bg-primary-600 text-white rounded-full">
                        {badge}
                    </span>
                )}
                <ChevronDownIcon className="h-4 w-4 text-neutral-500" />
            </MenuButton>

            <MenuItems
                className="absolute right-0 mt-3 w-48 origin-top-right bg-white shadow-xl rounded-xl p-3 z-20"
            >
                {options.map(opt => (
                    <MenuItem key={opt.value}>
                        <button
                            onClick={() => onChange(opt.value)}
                            className="flex items-center gap-2 w-full px-2 py-2 text-left text-sm rounded-lg hover:bg-neutral-100"
                        >
                            <input
                                type="checkbox"
                                readOnly
                                checked={selected === opt.value}
                                className="accent-primary-600"
                            />
                            {opt.label}
                        </button>
                    </MenuItem>
                ))}
            </MenuItems>
        </Menu>
    );
}
