"use client";

import { useNavigate } from "react-router-dom";

export default function CarCard({ car }) {
    const navigate = useNavigate();

    return (
        <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden hover:shadow-xl transition">

            {/* IMAGE */}
            <div className="w-full h-56 overflow-hidden">
                <img
                    src={car.TourImg || car.ImageUrl || car.MainImage || car.Img || "https://placehold.co/600x400"}
                    alt={car.ModelName}
                    className="w-full h-full object-cover"
                />
            </div>

            {/* CONTENT */}
            <div className="p-5 flex flex-col">

                <h3 className="text-lg font-semibold text-neutral-900">
                    {car.ModelName}
                </h3>

                <p className="text-neutral-500 text-sm mt-1">{car.Brand}</p>

                <div className="mt-3 text-primary-600 font-bold text-xl">
                    {car.DailyRate.toLocaleString("en-US", { style: "currency", currency: "USD" })} / day
                </div>

                {/* SEATS */}
                <div className="text-neutral-600 text-sm mt-2">
                    Seats: <span className="font-medium">{car.SeatingCapacity}</span>
                </div>

                {/* BUTTON */}
                <button
                    onClick={() => navigate(`/car/${car.CarID}`)}
                    className="mt-4 bg-primary-600 hover:bg-primary-700 text-white py-2 rounded-lg font-semibold transition"
                >
                    View Details
                </button>
            </div>
        </div>
    );
}
